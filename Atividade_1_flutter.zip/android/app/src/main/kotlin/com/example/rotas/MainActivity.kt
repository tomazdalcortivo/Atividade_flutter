package com.example.rotas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
